// Typing Effect

let text = "Hi, I'm Anbazhagan - BCA Student & Web Developer!";

let i = 0;

function typeWriter() {

  if (i < text.length) {

    document.getElementById("intro").innerHTML += text.charAt(i);

    i++;

    setTimeout(typeWriter, 100);

  }

}

typeWriter();

// Dark Mode Toggle

document.getElementById("darkModeBtn").addEventListener("click", function() {

  document.body.classList.toggle("dark-mode");

});

// Contact Form Validation

document.getElementById("contactForm").addEventListener("submit", function(e) {

  e.preventDefault();

  let name = document.getElementById("name").value;

  let email = document.getElementById("email").value;

  if(name === "" || email === "") {

    alert("Please fill all fields!");

  } else {

    alert("Thank you for your message, " + name + "!");

  }

});